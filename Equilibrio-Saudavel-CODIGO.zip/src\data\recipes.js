export const recipes = [
  {
    "id": 1,
    "name": "Aveia cremosa com banana",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "4 colheres (sopa) de aveia",
      "200 ml de leite",
      "1 banana madura",
      "Canela a gosto"
    ],
    "steps": [
      "Aqueça o leite em fogo baixo.",
      "Adicione a aveia e mexa até engrossar.",
      "Sirva com banana fatiada e canela."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite; aveia pode conter glúten.",
    "image": "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=700&q=80"
  },
  {
    "id": 2,
    "name": "Aveia cremosa com banana com ervas frescas",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "4 colheres (sopa) de aveia",
      "200 ml de leite",
      "1 banana madura",
      "Canela a gosto",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Aqueça o leite em fogo baixo.",
      "Adicione a aveia e mexa até engrossar.",
      "Sirva com banana fatiada e canela.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite; aveia pode conter glúten.",
    "image": "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=700&q=80"
  },
  {
    "id": 3,
    "name": "Aveia cremosa com banana com sementes",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "4 colheres (sopa) de aveia",
      "200 ml de leite",
      "1 banana madura",
      "Canela a gosto",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Aqueça o leite em fogo baixo.",
      "Adicione a aveia e mexa até engrossar.",
      "Sirva com banana fatiada e canela.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite; aveia pode conter glúten. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=700&q=80"
  },
  {
    "id": 4,
    "name": "Omelete de espinafre",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "2 ovos",
      "1 xícara de espinafre picado",
      "1 colher (chá) de azeite",
      "Sal e pimenta a gosto"
    ],
    "steps": [
      "Bata os ovos com o sal.",
      "Refogue o espinafre no azeite.",
      "Junte os ovos e cozinhe dos dois lados."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém ovos.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&q=80"
  },
  {
    "id": 5,
    "name": "Omelete de espinafre com ervas frescas",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "2 ovos",
      "1 xícara de espinafre picado",
      "1 colher (chá) de azeite",
      "Sal e pimenta a gosto",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Bata os ovos com o sal.",
      "Refogue o espinafre no azeite.",
      "Junte os ovos e cozinhe dos dois lados.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém ovos.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&q=80"
  },
  {
    "id": 6,
    "name": "Omelete de espinafre com sementes",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "2 ovos",
      "1 xícara de espinafre picado",
      "1 colher (chá) de azeite",
      "Sal e pimenta a gosto",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Bata os ovos com o sal.",
      "Refogue o espinafre no azeite.",
      "Junte os ovos e cozinhe dos dois lados.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém ovos. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&q=80"
  },
  {
    "id": 7,
    "name": "Tapioca com queijo branco",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "4 colheres (sopa) de goma de tapioca",
      "40 g de queijo minas",
      "1 tomate pequeno",
      "Orégano a gosto"
    ],
    "steps": [
      "Espalhe a goma em frigideira aquecida.",
      "Cozinhe até unir os grãos.",
      "Recheie com queijo, tomate e orégano e dobre."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite.",
    "image": "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=700&q=80"
  },
  {
    "id": 8,
    "name": "Tapioca com queijo branco com ervas frescas",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "4 colheres (sopa) de goma de tapioca",
      "40 g de queijo minas",
      "1 tomate pequeno",
      "Orégano a gosto",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Espalhe a goma em frigideira aquecida.",
      "Cozinhe até unir os grãos.",
      "Recheie com queijo, tomate e orégano e dobre.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite.",
    "image": "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=700&q=80"
  },
  {
    "id": 9,
    "name": "Tapioca com queijo branco com sementes",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "4 colheres (sopa) de goma de tapioca",
      "40 g de queijo minas",
      "1 tomate pequeno",
      "Orégano a gosto",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Espalhe a goma em frigideira aquecida.",
      "Cozinhe até unir os grãos.",
      "Recheie com queijo, tomate e orégano e dobre.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=700&q=80"
  },
  {
    "id": 10,
    "name": "Iogurte com frutas e granola",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "170 g de iogurte natural",
      "1 maçã",
      "2 colheres (sopa) de granola",
      "Canela a gosto"
    ],
    "steps": [
      "Higienize e pique a maçã.",
      "Coloque o iogurte em uma tigela.",
      "Cubra com maçã, granola e canela."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite; confira alérgenos da granola.",
    "image": "https://images.unsplash.com/photo-1547592180-85f173990554?w=700&q=80"
  },
  {
    "id": 11,
    "name": "Iogurte com frutas e granola com ervas frescas",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "170 g de iogurte natural",
      "1 maçã",
      "2 colheres (sopa) de granola",
      "Canela a gosto",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Higienize e pique a maçã.",
      "Coloque o iogurte em uma tigela.",
      "Cubra com maçã, granola e canela.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite; confira alérgenos da granola.",
    "image": "https://images.unsplash.com/photo-1547592180-85f173990554?w=700&q=80"
  },
  {
    "id": 12,
    "name": "Iogurte com frutas e granola com sementes",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "170 g de iogurte natural",
      "1 maçã",
      "2 colheres (sopa) de granola",
      "Canela a gosto",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Higienize e pique a maçã.",
      "Coloque o iogurte em uma tigela.",
      "Cubra com maçã, granola e canela.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite; confira alérgenos da granola. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1547592180-85f173990554?w=700&q=80"
  },
  {
    "id": 13,
    "name": "Panqueca de banana e aveia",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1 banana",
      "1 ovo",
      "3 colheres (sopa) de aveia",
      "Canela a gosto"
    ],
    "steps": [
      "Amasse a banana e misture com o ovo.",
      "Acrescente a aveia e a canela.",
      "Doure porções em frigideira antiaderente."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém ovo; aveia pode conter glúten.",
    "image": "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=700&q=80"
  },
  {
    "id": 14,
    "name": "Panqueca de banana e aveia com ervas frescas",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1 banana",
      "1 ovo",
      "3 colheres (sopa) de aveia",
      "Canela a gosto",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Amasse a banana e misture com o ovo.",
      "Acrescente a aveia e a canela.",
      "Doure porções em frigideira antiaderente.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém ovo; aveia pode conter glúten.",
    "image": "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=700&q=80"
  },
  {
    "id": 15,
    "name": "Panqueca de banana e aveia com sementes",
    "category": "Café da manhã",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1 banana",
      "1 ovo",
      "3 colheres (sopa) de aveia",
      "Canela a gosto",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Amasse a banana e misture com o ovo.",
      "Acrescente a aveia e a canela.",
      "Doure porções em frigideira antiaderente.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém ovo; aveia pode conter glúten. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=700&q=80"
  },
  {
    "id": 16,
    "name": "Arroz integral com frango e legumes",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1 xícara de arroz integral cozido",
      "150 g de peito de frango",
      "1 cenoura",
      "1/2 abobrinha",
      "1 colher (chá) de azeite"
    ],
    "steps": [
      "Cozinhe o arroz integral.",
      "Corte o frango e doure no azeite até cozinhar completamente.",
      "Refogue cenoura e abobrinha e sirva com o arroz."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos; confira ingredientes.",
    "image": "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=700&q=80"
  },
  {
    "id": 17,
    "name": "Arroz integral com frango e legumes com ervas frescas",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1 xícara de arroz integral cozido",
      "150 g de peito de frango",
      "1 cenoura",
      "1/2 abobrinha",
      "1 colher (chá) de azeite",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Cozinhe o arroz integral.",
      "Corte o frango e doure no azeite até cozinhar completamente.",
      "Refogue cenoura e abobrinha e sirva com o arroz.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos; confira ingredientes.",
    "image": "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=700&q=80"
  },
  {
    "id": 18,
    "name": "Arroz integral com frango e legumes com sementes",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1 xícara de arroz integral cozido",
      "150 g de peito de frango",
      "1 cenoura",
      "1/2 abobrinha",
      "1 colher (chá) de azeite",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Cozinhe o arroz integral.",
      "Corte o frango e doure no azeite até cozinhar completamente.",
      "Refogue cenoura e abobrinha e sirva com o arroz.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos; confira ingredientes. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=700&q=80"
  },
  {
    "id": 19,
    "name": "Salada de grão-de-bico",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1 xícara de grão-de-bico cozido",
      "1 tomate",
      "1/2 pepino",
      "Suco de 1/2 limão",
      "1 colher (sopa) de azeite"
    ],
    "steps": [
      "Cozinhe o grão-de-bico até ficar macio.",
      "Corte os vegetais em cubos.",
      "Misture tudo e tempere com limão e azeite."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos.",
    "image": "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=700&q=80"
  },
  {
    "id": 20,
    "name": "Salada de grão-de-bico com ervas frescas",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1 xícara de grão-de-bico cozido",
      "1 tomate",
      "1/2 pepino",
      "Suco de 1/2 limão",
      "1 colher (sopa) de azeite",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Cozinhe o grão-de-bico até ficar macio.",
      "Corte os vegetais em cubos.",
      "Misture tudo e tempere com limão e azeite.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos.",
    "image": "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=700&q=80"
  },
  {
    "id": 21,
    "name": "Salada de grão-de-bico com sementes",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1 xícara de grão-de-bico cozido",
      "1 tomate",
      "1/2 pepino",
      "Suco de 1/2 limão",
      "1 colher (sopa) de azeite",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Cozinhe o grão-de-bico até ficar macio.",
      "Corte os vegetais em cubos.",
      "Misture tudo e tempere com limão e azeite.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=700&q=80"
  },
  {
    "id": 22,
    "name": "Peixe assado com batatas",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "160 g de filé de tilápia",
      "1 batata média",
      "1 colher (sopa) de azeite",
      "Limão e ervas a gosto"
    ],
    "steps": [
      "Corte a batata em fatias finas.",
      "Tempere o peixe e as batatas.",
      "Asse a 200 °C até o peixe estar cozido e a batata macia."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém peixe.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&q=80"
  },
  {
    "id": 23,
    "name": "Peixe assado com batatas com ervas frescas",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "160 g de filé de tilápia",
      "1 batata média",
      "1 colher (sopa) de azeite",
      "Limão e ervas a gosto",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Corte a batata em fatias finas.",
      "Tempere o peixe e as batatas.",
      "Asse a 200 °C até o peixe estar cozido e a batata macia.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém peixe.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&q=80"
  },
  {
    "id": 24,
    "name": "Peixe assado com batatas com sementes",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "160 g de filé de tilápia",
      "1 batata média",
      "1 colher (sopa) de azeite",
      "Limão e ervas a gosto",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Corte a batata em fatias finas.",
      "Tempere o peixe e as batatas.",
      "Asse a 200 °C até o peixe estar cozido e a batata macia.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém peixe. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&q=80"
  },
  {
    "id": 25,
    "name": "Macarrão integral ao tomate",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "80 g de macarrão integral seco",
      "2 tomates maduros",
      "1 dente de alho",
      "1 colher (chá) de azeite",
      "Manjericão"
    ],
    "steps": [
      "Cozinhe o macarrão conforme a embalagem.",
      "Refogue o alho e os tomates picados.",
      "Misture o molho à massa e finalize com manjericão."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém trigo/glúten.",
    "image": "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=700&q=80"
  },
  {
    "id": 26,
    "name": "Macarrão integral ao tomate com ervas frescas",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "80 g de macarrão integral seco",
      "2 tomates maduros",
      "1 dente de alho",
      "1 colher (chá) de azeite",
      "Manjericão",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Cozinhe o macarrão conforme a embalagem.",
      "Refogue o alho e os tomates picados.",
      "Misture o molho à massa e finalize com manjericão.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém trigo/glúten.",
    "image": "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=700&q=80"
  },
  {
    "id": 27,
    "name": "Macarrão integral ao tomate com sementes",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "80 g de macarrão integral seco",
      "2 tomates maduros",
      "1 dente de alho",
      "1 colher (chá) de azeite",
      "Manjericão",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Cozinhe o macarrão conforme a embalagem.",
      "Refogue o alho e os tomates picados.",
      "Misture o molho à massa e finalize com manjericão.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém trigo/glúten. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=700&q=80"
  },
  {
    "id": 28,
    "name": "Quinoa com abóbora e feijão",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1/2 xícara de quinoa crua",
      "1 xícara de abóbora em cubos",
      "1/2 xícara de feijão cozido",
      "1 colher (chá) de azeite"
    ],
    "steps": [
      "Cozinhe a quinoa em água até amaciar.",
      "Asse a abóbora com azeite até ficar macia.",
      "Misture com o feijão aquecido e sirva."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos.",
    "image": "https://images.unsplash.com/photo-1547592180-85f173990554?w=700&q=80"
  },
  {
    "id": 29,
    "name": "Quinoa com abóbora e feijão com ervas frescas",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1/2 xícara de quinoa crua",
      "1 xícara de abóbora em cubos",
      "1/2 xícara de feijão cozido",
      "1 colher (chá) de azeite",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Cozinhe a quinoa em água até amaciar.",
      "Asse a abóbora com azeite até ficar macia.",
      "Misture com o feijão aquecido e sirva.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos.",
    "image": "https://images.unsplash.com/photo-1547592180-85f173990554?w=700&q=80"
  },
  {
    "id": 30,
    "name": "Quinoa com abóbora e feijão com sementes",
    "category": "Almoço",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1/2 xícara de quinoa crua",
      "1 xícara de abóbora em cubos",
      "1/2 xícara de feijão cozido",
      "1 colher (chá) de azeite",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Cozinhe a quinoa em água até amaciar.",
      "Asse a abóbora com azeite até ficar macia.",
      "Misture com o feijão aquecido e sirva.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1547592180-85f173990554?w=700&q=80"
  },
  {
    "id": 31,
    "name": "Sopa de legumes com frango",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "120 g de frango desfiado cozido",
      "1 cenoura",
      "1 batata",
      "1/2 chuchu",
      "500 ml de água"
    ],
    "steps": [
      "Corte os legumes em cubos.",
      "Cozinhe-os em água até amaciar.",
      "Junte o frango já cozido, aqueça e tempere."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos.",
    "image": "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=700&q=80"
  },
  {
    "id": 32,
    "name": "Sopa de legumes com frango com ervas frescas",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "120 g de frango desfiado cozido",
      "1 cenoura",
      "1 batata",
      "1/2 chuchu",
      "500 ml de água",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Corte os legumes em cubos.",
      "Cozinhe-os em água até amaciar.",
      "Junte o frango já cozido, aqueça e tempere.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos.",
    "image": "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=700&q=80"
  },
  {
    "id": 33,
    "name": "Sopa de legumes com frango com sementes",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "120 g de frango desfiado cozido",
      "1 cenoura",
      "1 batata",
      "1/2 chuchu",
      "500 ml de água",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Corte os legumes em cubos.",
      "Cozinhe-os em água até amaciar.",
      "Junte o frango já cozido, aqueça e tempere.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=700&q=80"
  },
  {
    "id": 34,
    "name": "Creme de abóbora",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "300 g de abóbora",
      "1/2 cebola",
      "1 colher (chá) de azeite",
      "300 ml de água"
    ],
    "steps": [
      "Refogue a cebola no azeite.",
      "Adicione abóbora e água e cozinhe até amaciar.",
      "Bata com cuidado até obter um creme e aqueça novamente."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos.",
    "image": "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=700&q=80"
  },
  {
    "id": 35,
    "name": "Creme de abóbora com ervas frescas",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "300 g de abóbora",
      "1/2 cebola",
      "1 colher (chá) de azeite",
      "300 ml de água",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Refogue a cebola no azeite.",
      "Adicione abóbora e água e cozinhe até amaciar.",
      "Bata com cuidado até obter um creme e aqueça novamente.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos.",
    "image": "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=700&q=80"
  },
  {
    "id": 36,
    "name": "Creme de abóbora com sementes",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "300 g de abóbora",
      "1/2 cebola",
      "1 colher (chá) de azeite",
      "300 ml de água",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Refogue a cebola no azeite.",
      "Adicione abóbora e água e cozinhe até amaciar.",
      "Bata com cuidado até obter um creme e aqueça novamente.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=700&q=80"
  },
  {
    "id": 37,
    "name": "Wrap de frango e alface",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1 pão tipo wrap integral",
      "100 g de frango cozido desfiado",
      "2 folhas de alface",
      "2 colheres (sopa) de iogurte natural"
    ],
    "steps": [
      "Aqueça levemente o wrap.",
      "Espalhe o iogurte e distribua frango e alface higienizada.",
      "Enrole e sirva."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém trigo/glúten e leite.",
    "image": "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=700&q=80"
  },
  {
    "id": 38,
    "name": "Wrap de frango e alface com ervas frescas",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1 pão tipo wrap integral",
      "100 g de frango cozido desfiado",
      "2 folhas de alface",
      "2 colheres (sopa) de iogurte natural",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Aqueça levemente o wrap.",
      "Espalhe o iogurte e distribua frango e alface higienizada.",
      "Enrole e sirva.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém trigo/glúten e leite.",
    "image": "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=700&q=80"
  },
  {
    "id": 39,
    "name": "Wrap de frango e alface com sementes",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1 pão tipo wrap integral",
      "100 g de frango cozido desfiado",
      "2 folhas de alface",
      "2 colheres (sopa) de iogurte natural",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Aqueça levemente o wrap.",
      "Espalhe o iogurte e distribua frango e alface higienizada.",
      "Enrole e sirva.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém trigo/glúten e leite. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=700&q=80"
  },
  {
    "id": 40,
    "name": "Ovos mexidos com tomate",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "2 ovos",
      "1 tomate pequeno",
      "1 colher (chá) de azeite",
      "Salsinha a gosto"
    ],
    "steps": [
      "Pique o tomate e refogue no azeite.",
      "Adicione os ovos batidos.",
      "Mexa até cozinhar completamente e finalize com salsinha."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém ovos.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&q=80"
  },
  {
    "id": 41,
    "name": "Ovos mexidos com tomate com ervas frescas",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "2 ovos",
      "1 tomate pequeno",
      "1 colher (chá) de azeite",
      "Salsinha a gosto",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Pique o tomate e refogue no azeite.",
      "Adicione os ovos batidos.",
      "Mexa até cozinhar completamente e finalize com salsinha.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém ovos.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&q=80"
  },
  {
    "id": 42,
    "name": "Ovos mexidos com tomate com sementes",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "2 ovos",
      "1 tomate pequeno",
      "1 colher (chá) de azeite",
      "Salsinha a gosto",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Pique o tomate e refogue no azeite.",
      "Adicione os ovos batidos.",
      "Mexa até cozinhar completamente e finalize com salsinha.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém ovos. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&q=80"
  },
  {
    "id": 43,
    "name": "Salada morna de lentilhas",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1 xícara de lentilhas cozidas",
      "1 cenoura pequena",
      "1/2 cebola",
      "1 colher (sopa) de azeite"
    ],
    "steps": [
      "Cozinhe as lentilhas até ficarem macias.",
      "Refogue cebola e cenoura picadas.",
      "Misture às lentilhas e sirva morno."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos.",
    "image": "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=700&q=80"
  },
  {
    "id": 44,
    "name": "Salada morna de lentilhas com ervas frescas",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1 xícara de lentilhas cozidas",
      "1 cenoura pequena",
      "1/2 cebola",
      "1 colher (sopa) de azeite",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Cozinhe as lentilhas até ficarem macias.",
      "Refogue cebola e cenoura picadas.",
      "Misture às lentilhas e sirva morno.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos.",
    "image": "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=700&q=80"
  },
  {
    "id": 45,
    "name": "Salada morna de lentilhas com sementes",
    "category": "Jantar",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 25,
    "servings": 2,
    "difficulty": "Fácil",
    "ingredients": [
      "1 xícara de lentilhas cozidas",
      "1 cenoura pequena",
      "1/2 cebola",
      "1 colher (sopa) de azeite",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Cozinhe as lentilhas até ficarem macias.",
      "Refogue cebola e cenoura picadas.",
      "Misture às lentilhas e sirva morno.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=700&q=80"
  },
  {
    "id": 46,
    "name": "Sanduíche natural de atum",
    "category": "Lanches",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "2 fatias de pão integral",
      "1/2 lata de atum escorrido",
      "1 colher (sopa) de iogurte",
      "2 folhas de alface"
    ],
    "steps": [
      "Misture o atum com iogurte.",
      "Higienize a alface.",
      "Monte o sanduíche e sirva."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém peixe, trigo/glúten e leite.",
    "image": "https://images.unsplash.com/photo-1547592180-85f173990554?w=700&q=80"
  },
  {
    "id": 47,
    "name": "Sanduíche natural de atum com ervas frescas",
    "category": "Lanches",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "2 fatias de pão integral",
      "1/2 lata de atum escorrido",
      "1 colher (sopa) de iogurte",
      "2 folhas de alface",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Misture o atum com iogurte.",
      "Higienize a alface.",
      "Monte o sanduíche e sirva.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém peixe, trigo/glúten e leite.",
    "image": "https://images.unsplash.com/photo-1547592180-85f173990554?w=700&q=80"
  },
  {
    "id": 48,
    "name": "Sanduíche natural de atum com sementes",
    "category": "Lanches",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "2 fatias de pão integral",
      "1/2 lata de atum escorrido",
      "1 colher (sopa) de iogurte",
      "2 folhas de alface",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Misture o atum com iogurte.",
      "Higienize a alface.",
      "Monte o sanduíche e sirva.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém peixe, trigo/glúten e leite. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1547592180-85f173990554?w=700&q=80"
  },
  {
    "id": 49,
    "name": "Maçã assada com canela",
    "category": "Sobremesas",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1 maçã",
      "1 colher (chá) de mel",
      "Canela a gosto"
    ],
    "steps": [
      "Retire as sementes da maçã.",
      "Coloque em recipiente próprio para forno.",
      "Asse a 180 °C até ficar macia e finalize com mel e canela."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos; mel não indicado a menores de 1 ano.",
    "image": "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=700&q=80"
  },
  {
    "id": 50,
    "name": "Maçã assada com canela com ervas frescas",
    "category": "Sobremesas",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1 maçã",
      "1 colher (chá) de mel",
      "Canela a gosto",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Retire as sementes da maçã.",
      "Coloque em recipiente próprio para forno.",
      "Asse a 180 °C até ficar macia e finalize com mel e canela.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos; mel não indicado a menores de 1 ano.",
    "image": "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=700&q=80"
  },
  {
    "id": 51,
    "name": "Maçã assada com canela com sementes",
    "category": "Sobremesas",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1 maçã",
      "1 colher (chá) de mel",
      "Canela a gosto",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Retire as sementes da maçã.",
      "Coloque em recipiente próprio para forno.",
      "Asse a 180 °C até ficar macia e finalize com mel e canela.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Sem alérgenos principais previstos; mel não indicado a menores de 1 ano. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=700&q=80"
  },
  {
    "id": 52,
    "name": "Mousse simples de cacau e banana",
    "category": "Sobremesas",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1 banana congelada",
      "1 colher (sopa) de cacau em pó",
      "2 colheres (sopa) de leite"
    ],
    "steps": [
      "Corte e congele a banana.",
      "Bata a banana com cacau e leite até ficar cremoso.",
      "Sirva imediatamente."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite.",
    "image": "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=700&q=80"
  },
  {
    "id": 53,
    "name": "Mousse simples de cacau e banana com ervas frescas",
    "category": "Sobremesas",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1 banana congelada",
      "1 colher (sopa) de cacau em pó",
      "2 colheres (sopa) de leite",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Corte e congele a banana.",
      "Bata a banana com cacau e leite até ficar cremoso.",
      "Sirva imediatamente.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite.",
    "image": "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=700&q=80"
  },
  {
    "id": 54,
    "name": "Mousse simples de cacau e banana com sementes",
    "category": "Sobremesas",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1 banana congelada",
      "1 colher (sopa) de cacau em pó",
      "2 colheres (sopa) de leite",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Corte e congele a banana.",
      "Bata a banana com cacau e leite até ficar cremoso.",
      "Sirva imediatamente.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=700&q=80"
  },
  {
    "id": 55,
    "name": "Smoothie de morango",
    "category": "Preparações rápidas",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1 xícara de morangos",
      "170 g de iogurte natural",
      "1/2 banana",
      "100 ml de água"
    ],
    "steps": [
      "Higienize os morangos.",
      "Bata todos os ingredientes no liquidificador.",
      "Sirva gelado."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite.",
    "image": "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=700&q=80"
  },
  {
    "id": 56,
    "name": "Smoothie de morango com ervas frescas",
    "category": "Preparações rápidas",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1 xícara de morangos",
      "170 g de iogurte natural",
      "1/2 banana",
      "100 ml de água",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Higienize os morangos.",
      "Bata todos os ingredientes no liquidificador.",
      "Sirva gelado.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite.",
    "image": "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=700&q=80"
  },
  {
    "id": 57,
    "name": "Smoothie de morango com sementes",
    "category": "Preparações rápidas",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1 xícara de morangos",
      "170 g de iogurte natural",
      "1/2 banana",
      "100 ml de água",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Higienize os morangos.",
      "Bata todos os ingredientes no liquidificador.",
      "Sirva gelado.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém leite. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=700&q=80"
  },
  {
    "id": 58,
    "name": "Cuscuz com ovo",
    "category": "Preparações rápidas",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1/2 xícara de flocão de milho",
      "1/4 xícara de água",
      "1 ovo",
      "1 colher (chá) de azeite"
    ],
    "steps": [
      "Hidrate o flocão com água por 10 minutos.",
      "Cozinhe no vapor por cerca de 10 minutos.",
      "Prepare o ovo bem cozido na frigideira e sirva junto."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém ovos.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&q=80"
  },
  {
    "id": 59,
    "name": "Cuscuz com ovo com ervas frescas",
    "category": "Preparações rápidas",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1/2 xícara de flocão de milho",
      "1/4 xícara de água",
      "1 ovo",
      "1 colher (chá) de azeite",
      "1 colher (sopa) de salsinha ou hortelã picada"
    ],
    "steps": [
      "Hidrate o flocão com água por 10 minutos.",
      "Cozinhe no vapor por cerca de 10 minutos.",
      "Prepare o ovo bem cozido na frigideira e sirva junto.",
      "Finalize a preparação com ervas frescas picadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém ovos.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&q=80"
  },
  {
    "id": 60,
    "name": "Cuscuz com ovo com sementes",
    "category": "Preparações rápidas",
    "description": "Uma opção caseira e prática para variar o cardápio com ingredientes acessíveis.",
    "time": 15,
    "servings": 1,
    "difficulty": "Fácil",
    "ingredients": [
      "1/2 xícara de flocão de milho",
      "1/4 xícara de água",
      "1 ovo",
      "1 colher (chá) de azeite",
      "1 colher (chá) de sementes de chia ou gergelim"
    ],
    "steps": [
      "Hidrate o flocão com água por 10 minutos.",
      "Cozinhe no vapor por cerca de 10 minutos.",
      "Prepare o ovo bem cozido na frigideira e sirva junto.",
      "Finalize a preparação com as sementes indicadas."
    ],
    "tip": "Ajuste temperos ao seu gosto e higienize bem os vegetais.",
    "allergens": "Contém ovos. Verifique gergelim, se utilizado.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&q=80"
  }
];